from ClassNewMenu import *

menuDeOpcoes = Menu()