from tkinter import *
import posiciona
from ClassNewEstoque import *
from ClasseCompra import *
from ClasseVenda import *

class Interface:
    def __init__(self):
        cadastro = NewEstoque()
        compra = Compra()
        venda = Venda()
        compra.entrada = cadastro
        venda.entrada = cadastro

        self.windowStoq = Tk()

        self.windowStoq.geometry('990x600+200+200')
        self.windowStoq.title('Estoque')
        self.windowStoq.resizable(width=False, height=False)

        self.windowStoq.bind('<Button-1>', posiciona.inicio_place)
        self.windowStoq.bind('<ButtonRelease-1>', lambda arg: posiciona.fim_place(arg, self.windowStoq))
        self.windowStoq.bind('<Button-2>', lambda arg: posiciona.para_geometry(self.windowStoq))

        # =======================================| Definindo Imagens do Primeiro Frame |=========================================
        self.telaMenu = PhotoImage(file='Canva/1.png')

        self.bCadFabr = PhotoImage(file='Canva/BotaoCadFabric.png')
        self.bCadProd = PhotoImage(file='Canva/BotaoCadProd.png')
        self.bProcProd = PhotoImage(file='Canva/BotaoProcProd.png')
        self.bAltProd = PhotoImage(file='Canva/BotaoAltProd.png')
        self.bDelProd = PhotoImage(file='Canva/BotaoDelProd.png')
        self.bDelFabri = PhotoImage(file='Canva/BotaoDelFabri.png')
        self.bAbast = PhotoImage(file='Canva/BotaoAbast.png')
        self.bRetir = PhotoImage(file='Canva/BotaoRetira.png')
        self.bHistEntr = PhotoImage(file='Canva/BotaoHistEntr.png')
        self.bHistSaid = PhotoImage(file='Canva/BotaoHistSaid.png')
        self.bsair = PhotoImage(file='Canva/BotaoSaida.png')


        # ========================================| Definindo Imagens do Segundo Frame |=========================================
        self.cadFabri = PhotoImage(file='Canva/2.png')

        self.bSalvar = PhotoImage(file='Canva/BotaoSalvar1.png')

        self.bVoltar = PhotoImage(file='Canva/BotaoVoltar.png')


        # =======================================| Definindo Imagens do Terceiro Frame |=========================================
        self.cadProd = PhotoImage(file='Canva/3.png')

        # ========================================| Definindo Imagens do Quarto Frame |==========================================
        self.listProd = PhotoImage(file='Canva/4.png')

        # =========================================| Definindo Imagens do Quinto Frame |=========================================
        self.altProd = PhotoImage(file='Canva/5.png')

        # ==========================================| Definindo Imagens do Sexto Frame |=========================================
        self.deletProd = PhotoImage(file='Canva/6.png')

        # ==========================================| Definindo Imagens do Sétimo Frame |========================================
        self.deletFabr = PhotoImage(file='Canva/7.png')


        # =================================================| Criando Frames |====================================================
        self.f1 = Frame(self.windowStoq)
        self.f1.pack()
        self.f2 = Frame(self.windowStoq)
        self.f3 = Frame(self.windowStoq)
        self.f4 = Frame(self.windowStoq)
        self.f5 = Frame(self.windowStoq)
        self.f6 = Frame(self.windowStoq)
        self.f7 = Frame(self.windowStoq)


        # ============================================| Criando Primeiro Frame |===============================================
        self.lab_TelaMenu = Label(self.f1, image=self.telaMenu)
        self.lab_TelaMenu.pack()

        self.b1 = Button(self.f1, image=self.bCadFabr, bd=0, command=self.cadastro_fabricante)
        self.b1.place(width=203, height=108, x=322, y=35)

        self.b2 = Button(self.f1, image=self.bCadProd, bd=0, command=self.cadastro_produto)
        self.b2.place(width=206, height=117, x=541, y=30)

        self.b3 = Button(self.f1, image=self.bProcProd, bd=0, command=self.procura_produto)
        self.b3.place(width=205, height=112, x=762, y=32)

        self.b4 = Button(self.f1, image=self.bAltProd, bd=0, command=self.alterar_produto)
        self.b4.place(width=208, height=113, x=318, y=172)

        self.b5 = Button(self.f1, image=self.bDelProd, bd=0, command=self.deletar_produto)
        self.b5.place(width=206, height=107, x=538, y=177)

        self.b6 = Button(self.f1, image=self.bDelFabri, bd=0, command=self.deletar_fabricante)
        self.b6.place(width=203, height=110, x=761, y=177)


        # ===================================================| Criando Segundo Frame |===========================================
        self.lab_CadFabri = Label(self.f2, image=self.cadFabri)
        self.lab_CadFabri.pack()

        self.b7 = Button(self.f2, bd=0, image=self.bSalvar)
        self.b7.place(width=212, height=72, x=388, y=501)

        self.b8 = Button(self.f2, bd=0, image=self.bVoltar, command=lambda: [self.f2.forget(), self.f1.pack()])
        self.b8.place(width=58, height=56, x=26, y=17)

        self.ent1 = Entry(self.f2, bd=0, bg='#FFE3D5', justify='center')
        self.ent1.place(width=440, height=23, x=479, y=212)

        self.ent2 = Entry(self.f2, bd=0, bg='#FFE3D5', justify='center')
        self.ent2.place(width=440, height=23, x=479, y=321)

        self.ent3 = Entry(self.f2, bd=0, bg='#FFE3D5', justify='center')
        self.ent3.place(width=440, height=23, x=479, y=431)


        #===================================================| Criando Terceiro Frame |============================================
        self.lab_CadProd = Label(self.f3, image=self.cadProd)
        self.lab_CadProd.pack()

        self.b9 = Button(self.f3, bd=0, image=self.bSalvar)
        self.b9.place(width=213, height=72, x=386, y=498)

        self.b10 = Button(self.f3, bd=0, image=self.bVoltar, command=lambda: [self.f3.forget(), self.f1.pack()])
        self.b10.place(width=58, height=56, x=26, y=17)

        self.ent4 = Entry(self.f3, bd=0, bg='#FFE3D5', justify='center')
        self.ent4.place(width=441, height=24, x=478, y=244)

        self.ent5 = Entry(self.f3, bd=0, bg='#FFE3D5', justify='center')
        self.ent5.place(width=441, height=24, x=478, y=388)



        self.windowStoq.mainloop()

#============================================| Definicação de comandos |=================================================
    def cadastro_fabricante(self):
        self.f1.forget()
        self.f2.pack()

    def cadastro_produto(self):
        self.f1.forget()
        self.f3.pack()

    def procura_produto(self):
        self.f1.forget()
        self.f4.pack()

    def alterar_produto(self):
        self.f1.forget()
        self.f5.pack()

    def deletar_produto(self):
        self.f1.forget()
        self.f6.pack()

    def deletar_fabricante(self):
        self.f1.forget()
        self.f7.pack()


janela = Interface()
