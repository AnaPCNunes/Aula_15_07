class Fabricante:
    def __init__(self, cod, nome, cnpj, razaoSocial):
        self.cod = cod
        self.nome = nome
        self.cnpj = cnpj
        self.razaoSocial = razaoSocial