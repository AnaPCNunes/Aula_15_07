class Produto:
    def __init__(self, cod, descr, cod_fabricante, quant):
        self.cod = cod
        self.descr = descr
        self.cod_fabricante = cod_fabricante
        self.quant = quant
