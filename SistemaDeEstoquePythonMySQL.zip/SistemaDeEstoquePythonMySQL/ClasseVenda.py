from ClasseEstoque import *

class Venda:
    def __init__(self):
        self.retira = []
        self.entrada = Estoque()

    def vender(self):
        count = 0
        entrada1 = input('\nInforme o código do produto: ')
        for i in range(len(self.entrada.listaProdutos)):
            if entrada1 == self.entrada.listaProdutos[i].cod:
                sa = int(input('Informe a quantidade vendida: '))
                if sa < self.entrada.listaProdutos:
                    self.entrada.listaProdutos[i].quant -= sa
                    self.retira.append(f'Saída de {sa} unidades do produto ' + self.entrada.listaProdutos[i].cod)
                else:
                    print('Valor inserido é maior do que há no estoque!\n'
                          'Favor informar uma quantidade válida!')
            else:
                count += 1
                if count == len(self.entrada.listaProdutos):
                    print('Não há produto cadastrado com este código!')

    def imprimir_retira(self):
        for i in self.retira:
            print('\n ', i)
            print('')