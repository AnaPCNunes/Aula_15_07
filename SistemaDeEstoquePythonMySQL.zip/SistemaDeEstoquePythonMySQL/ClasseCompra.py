from ClasseEstoque import *

class Compra:
    def __init__(self):
        self.abast = []
        self.entrada = Estoque()

    def comprar(self):
        count = 0
        entrada1 = input('\nInforme o código do produto: ')
        for i in range(len(self.entrada.listaProdutos)):
            if entrada1 == self.entrada.listaProdutos[i].cod:
                en = int(input('Informe a quantidade comprada: '))
                self.entrada.listaProdutos[i].quant += en
                self.abast.append(f'Entrada de {en} unidades do produto ' + self.entrada.listaProdutos[i].cod)
            else:
                count += 1
                if count == len(self.entrada.listaProdutos):
                    print('Não há produto cadastrado com este código!')

    def imprimir_abast(self):
        for i in self.abast:
            print('\n ', i)
            print('')
